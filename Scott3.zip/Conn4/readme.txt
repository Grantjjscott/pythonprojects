Use python 3 and pip3 

pip install pygame
pip install numpy

python driverAI.py

to uninstall simply change ‘install’ to ‘uninstall’
